package com.sekhar.server_registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
